This is how we divided up our work:
Siyu Chen  chensiyuwilliam@hotmail.com
Tested Project2 1A and made sure the load function works as expected.

Roland Zeng   roland.zeng@gmail.com
Wrote and implemented the load function.
